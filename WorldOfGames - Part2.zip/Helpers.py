import os


def clear_console():
    print(("\n" * 1000))


def correct_range_input(min_value, max_value, user_input):
    return max_value >= user_input >= min_value



